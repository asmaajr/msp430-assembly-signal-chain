#ifndef _bsp_H_
#define _bsp_H_

#include  <msp430G2553.h>          // MSP430x2xx
// #include  <msp430xG46x.h>  // MSP430x4xx




#define         LCD_DATA_Byte  &P2OUT 
#define         LCD_CONTROL    &P1OUT
#define         state          R6               ; define R6 as our state in the FSM
#define         counter        R5
#define         sum            R14

#endif



